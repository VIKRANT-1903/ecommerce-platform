package com.example.ecomm.order.entity;

/**
 * Order lifecycle status.
 */
public enum OrderStatus {
    CREATED,
    PAID,
    FAILED
}
