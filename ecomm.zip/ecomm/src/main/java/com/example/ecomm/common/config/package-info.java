/**
 * Shared configuration and beans for the e-commerce application.
 */
package com.example.ecomm.common.config;
