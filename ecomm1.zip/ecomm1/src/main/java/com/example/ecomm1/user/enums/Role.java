package com.example.ecomm1.user.enums;

public enum Role {
    CUSTOMER,
    MERCHANT,
    ADMIN
}
