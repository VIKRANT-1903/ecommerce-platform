package com.example.ecomm1.offer.enums;

public enum OfferStatus {
    ACTIVE,
    INACTIVE,
    EXPIRED,
    OUT_OF_STOCK
}
