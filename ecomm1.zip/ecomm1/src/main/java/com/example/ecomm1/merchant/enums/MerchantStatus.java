package com.example.ecomm1.merchant.enums;

public enum MerchantStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}
