package com.example.ecomm1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ecomm1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ecomm1Application.class, args);
	}

}
