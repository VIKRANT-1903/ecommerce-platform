package com.example.ecomm1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ecomm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
